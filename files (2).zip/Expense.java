package com.finova.entity;

import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;
import java.math.BigDecimal;

@Entity
@DiscriminatorValue("EXPENSE")
public class Expense extends Transaction {

    @Override
    public TransactionType getType() { return TransactionType.EXPENSE; }

    @Override
    public BigDecimal signedAmount() { return getAmount().negate(); }
}
