package com.finova.controller;

import com.finova.entity.Income;
import com.finova.service.IncomeService;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/incomes")
public class IncomeController extends AbstractTransactionController<Income> {
    public IncomeController(IncomeService service) { super(service); }
}
