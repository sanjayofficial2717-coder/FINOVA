package com.finova.service;

import com.finova.entity.Expense;
import com.finova.entity.TransactionType;
import com.finova.repository.CategoryRepository;
import com.finova.repository.ExpenseRepository;
import org.springframework.stereotype.Service;

@Service
public class ExpenseService extends AbstractTransactionService<Expense> {

    public ExpenseService(ExpenseRepository repository, CategoryRepository categories) {
        super(repository, categories);
    }

    @Override
    protected Expense newInstance() { return new Expense(); }

    @Override
    public TransactionType type() { return TransactionType.EXPENSE; }
}
