package com.finova.dto;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import java.math.BigDecimal;

public final class BudgetDtos {
    private BudgetDtos() { }

    public record BudgetRequest(
            @NotNull Long categoryId,
            @Min(2000) @Max(2100) int year,
            @Min(1) @Max(12) int month,
            @NotNull @DecimalMin("0.01") @Digits(integer = 12, fraction = 2) BigDecimal limitAmount) { }

    public record BudgetResponse(Long id, Long categoryId, String categoryName, int year, int month,
                                 BigDecimal limitAmount, BigDecimal spent, BigDecimal remaining,
                                 double percentUsed, boolean exceeded) { }
}
