package com.finova.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public final class AuthDtos {
    private AuthDtos() { }

    public record RegisterRequest(
            @NotBlank @Size(max = 100) String name,
            @NotBlank @Email @Size(max = 150) String email,
            @NotBlank @Size(min = 8, max = 72, message = "password must be 8-72 characters") String password) { }

    public record LoginRequest(@NotBlank @Email String email, @NotBlank String password) { }

    public record AuthResponse(String token, String name, String email) { }
}
