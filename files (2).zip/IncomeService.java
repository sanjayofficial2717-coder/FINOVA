package com.finova.service;

import com.finova.entity.Income;
import com.finova.entity.TransactionType;
import com.finova.repository.CategoryRepository;
import com.finova.repository.IncomeRepository;
import org.springframework.stereotype.Service;

@Service
public class IncomeService extends AbstractTransactionService<Income> {

    public IncomeService(IncomeRepository repository, CategoryRepository categories) {
        super(repository, categories);
    }

    @Override
    protected Income newInstance() { return new Income(); }

    @Override
    public TransactionType type() { return TransactionType.INCOME; }
}
