package com.finova.dto;

import com.finova.entity.Category;
import com.finova.entity.TransactionType;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public final class CategoryDtos {
    private CategoryDtos() { }

    public record CategoryRequest(@NotBlank @Size(max = 50) String name, @NotNull TransactionType type) { }

    public record CategoryResponse(Long id, String name, TransactionType type) {
        public static CategoryResponse from(Category c) {
            return new CategoryResponse(c.getId(), c.getName(), c.getType());
        }
    }
}
