package com.finova.controller;

import com.finova.dto.CategoryDtos.CategoryRequest;
import com.finova.dto.CategoryDtos.CategoryResponse;
import com.finova.entity.User;
import com.finova.service.CategoryService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/categories")
public class CategoryController {

    private final CategoryService service;

    public CategoryController(CategoryService service) {
        this.service = service;
    }

    @GetMapping
    public List<CategoryResponse> list(@AuthenticationPrincipal User user) {
        return service.list(user);
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public CategoryResponse create(@AuthenticationPrincipal User user, @Valid @RequestBody CategoryRequest req) {
        return service.create(user, req);
    }

    @PutMapping("/{id}")
    public CategoryResponse update(@AuthenticationPrincipal User user, @PathVariable Long id,
                                   @Valid @RequestBody CategoryRequest req) {
        return service.update(user, id, req);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@AuthenticationPrincipal User user, @PathVariable Long id) {
        service.delete(user, id);
    }
}
