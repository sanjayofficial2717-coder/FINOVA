package com.finova.service;

import com.finova.dto.CategoryDtos.CategoryRequest;
import com.finova.dto.CategoryDtos.CategoryResponse;
import com.finova.entity.Category;
import com.finova.entity.User;
import com.finova.exception.DuplicateResourceException;
import com.finova.exception.ResourceNotFoundException;
import com.finova.repository.CategoryRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service
@Transactional
public class CategoryService {

    private final CategoryRepository categories;

    public CategoryService(CategoryRepository categories) {
        this.categories = categories;
    }

    @Transactional(readOnly = true)
    public List<CategoryResponse> list(User user) {
        return categories.findByUserOrderByNameAsc(user).stream().map(CategoryResponse::from).toList();
    }

    public CategoryResponse create(User user, CategoryRequest req) {
        String name = req.name().trim();
        if (categories.existsByUserAndNameIgnoreCaseAndType(user, name, req.type())) {
            throw new DuplicateResourceException("Category already exists");
        }
        return CategoryResponse.from(categories.save(new Category(name, req.type(), user)));
    }

    public CategoryResponse update(User user, Long id, CategoryRequest req) {
        Category c = find(user, id);
        String name = req.name().trim();
        boolean changed = !c.getName().equalsIgnoreCase(name) || c.getType() != req.type();
        if (changed && categories.existsByUserAndNameIgnoreCaseAndType(user, name, req.type())) {
            throw new DuplicateResourceException("Category already exists");
        }
        c.setName(name);
        c.setType(req.type());
        return CategoryResponse.from(c);
    }

    public void delete(User user, Long id) {
        categories.delete(find(user, id));
        categories.flush(); // surfaces FK violations (category in use) as a 409
    }

    private Category find(User user, Long id) {
        return categories.findByIdAndUser(id, user)
                .orElseThrow(() -> new ResourceNotFoundException("Category not found"));
    }
}
