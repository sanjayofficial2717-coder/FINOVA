package com.finova;

import com.finova.entity.Expense;
import com.finova.entity.Income;
import com.finova.entity.Transaction;
import com.finova.security.JwtService;
import io.jsonwebtoken.JwtException;
import org.junit.jupiter.api.Test;
import java.math.BigDecimal;
import java.util.Base64;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

class DomainAndSecurityTest {

    private static final String SECRET = Base64.getEncoder()
            .encodeToString("test-secret-key-that-is-at-least-32-bytes-long!!".getBytes());

    @Test
    void polymorphicSignedAmounts() {
        Income in = new Income();
        in.setAmount(new BigDecimal("100.00"));
        Expense ex = new Expense();
        ex.setAmount(new BigDecimal("40.00"));
        List<Transaction> all = List.of(in, ex);
        BigDecimal net = all.stream().map(Transaction::signedAmount).reduce(BigDecimal.ZERO, BigDecimal::add);
        assertEquals(new BigDecimal("60.00"), net);
    }

    @Test
    void jwtRoundTrip() {
        JwtService jwt = new JwtService(SECRET, 60_000);
        assertEquals("a@b.com", jwt.extractEmail(jwt.generateToken("a@b.com")));
    }

    @Test
    void jwtRejectsTamperedAndExpiredTokens() {
        JwtService jwt = new JwtService(SECRET, 60_000);
        assertThrows(JwtException.class, () -> jwt.extractEmail(jwt.generateToken("a@b.com") + "x"));
        JwtService expired = new JwtService(SECRET, -1000);
        assertThrows(JwtException.class, () -> expired.extractEmail(expired.generateToken("a@b.com")));
    }
}
