package com.finova.repository;

import com.finova.entity.Budget;
import com.finova.entity.Category;
import com.finova.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface BudgetRepository extends JpaRepository<Budget, Long> {
    List<Budget> findByUserAndPeriodYearAndPeriodMonth(User user, int year, int month);
    Optional<Budget> findByIdAndUser(Long id, User user);
    boolean existsByUserAndCategoryAndPeriodYearAndPeriodMonth(User user, Category category, int year, int month);
}
