package com.finova.repository;

import com.finova.entity.Category;
import com.finova.entity.TransactionType;
import com.finova.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface CategoryRepository extends JpaRepository<Category, Long> {
    List<Category> findByUserOrderByNameAsc(User user);
    Optional<Category> findByIdAndUser(Long id, User user);
    boolean existsByUserAndNameIgnoreCaseAndType(User user, String name, TransactionType type);
}
