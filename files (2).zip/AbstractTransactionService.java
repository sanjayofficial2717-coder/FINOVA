package com.finova.service;

import com.finova.dto.TransactionDtos.TransactionRequest;
import com.finova.dto.TransactionDtos.TransactionResponse;
import com.finova.entity.Category;
import com.finova.entity.Transaction;
import com.finova.entity.TransactionType;
import com.finova.entity.User;
import com.finova.exception.BadRequestException;
import com.finova.exception.ResourceNotFoundException;
import com.finova.repository.CategoryRepository;
import com.finova.repository.TransactionRepository;
import org.springframework.transaction.annotation.Transactional;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

/**
 * Template for income and expense services (abstraction + inheritance). Subclasses only supply the
 * concrete entity factory and type; all CRUD and total calculations are shared.
 * Every query is scoped to the authenticated user, which enforces user-data isolation.
 */
@Transactional
public abstract class AbstractTransactionService<T extends Transaction> {

    protected final TransactionRepository<T> repository;
    protected final CategoryRepository categories;

    protected AbstractTransactionService(TransactionRepository<T> repository, CategoryRepository categories) {
        this.repository = repository;
        this.categories = categories;
    }

    protected abstract T newInstance();

    public abstract TransactionType type();

    @Transactional(readOnly = true)
    public List<TransactionResponse> list(User user) {
        return repository.findByUserOrderByDateDescIdDesc(user).stream().map(TransactionResponse::from).toList();
    }

    @Transactional(readOnly = true)
    public TransactionResponse get(User user, Long id) {
        return TransactionResponse.from(find(user, id));
    }

    public TransactionResponse create(User user, TransactionRequest req) {
        T t = newInstance();
        t.setUser(user);
        apply(t, user, req);
        return TransactionResponse.from(repository.save(t));
    }

    public TransactionResponse update(User user, Long id, TransactionRequest req) {
        T t = find(user, id);
        apply(t, user, req);
        return TransactionResponse.from(t);
    }

    public void delete(User user, Long id) {
        repository.delete(find(user, id));
    }

    @Transactional(readOnly = true)
    public List<T> recent(User user) {
        return repository.findTop5ByUserOrderByDateDescIdDesc(user);
    }

    @Transactional(readOnly = true)
    public BigDecimal totalAll(User user) {
        return orZero(repository.sumAll(user));
    }

    @Transactional(readOnly = true)
    public BigDecimal totalBetween(User user, LocalDate from, LocalDate to) {
        return orZero(repository.sumBetween(user, from, to));
    }

    @Transactional(readOnly = true)
    public BigDecimal totalForCategory(User user, Category category, LocalDate from, LocalDate to) {
        return orZero(repository.sumByCategoryBetween(user, category, from, to));
    }

    private T find(User user, Long id) {
        return repository.findByIdAndUser(id, user)
                .orElseThrow(() -> new ResourceNotFoundException("Transaction not found"));
    }

    private void apply(T t, User user, TransactionRequest req) {
        t.setAmount(req.amount());
        t.setDescription(req.description() == null ? null : req.description().trim());
        t.setDate(req.date());
        if (req.categoryId() == null) {
            t.setCategory(null);
            return;
        }
        Category c = categories.findByIdAndUser(req.categoryId(), user)
                .orElseThrow(() -> new ResourceNotFoundException("Category not found"));
        if (c.getType() != type()) {
            throw new BadRequestException("Category type must be " + type());
        }
        t.setCategory(c);
    }

    private static BigDecimal orZero(BigDecimal v) {
        return v == null ? BigDecimal.ZERO : v;
    }
}
