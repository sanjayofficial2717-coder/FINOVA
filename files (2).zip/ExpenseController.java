package com.finova.controller;

import com.finova.entity.Expense;
import com.finova.service.ExpenseService;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/expenses")
public class ExpenseController extends AbstractTransactionController<Expense> {
    public ExpenseController(ExpenseService service) { super(service); }
}
