package com.finova.entity;

public enum TransactionType { INCOME, EXPENSE }
