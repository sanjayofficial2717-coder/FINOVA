package com.finova.repository;

import com.finova.entity.Category;
import com.finova.entity.Transaction;
import com.finova.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.NoRepositoryBean;
import org.springframework.data.repository.query.Param;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

/** Shared repository abstraction; IncomeRepository and ExpenseRepository bind it to a concrete entity. */
@NoRepositoryBean
public interface TransactionRepository<T extends Transaction> extends JpaRepository<T, Long> {

    List<T> findByUserOrderByDateDescIdDesc(User user);

    List<T> findTop5ByUserOrderByDateDescIdDesc(User user);

    Optional<T> findByIdAndUser(Long id, User user);

    @Query("select sum(t.amount) from #{#entityName} t where t.user = :user")
    BigDecimal sumAll(@Param("user") User user);

    @Query("select sum(t.amount) from #{#entityName} t "
            + "where t.user = :user and t.date between :from and :to")
    BigDecimal sumBetween(@Param("user") User user, @Param("from") LocalDate from, @Param("to") LocalDate to);

    @Query("select sum(t.amount) from #{#entityName} t "
            + "where t.user = :user and t.category = :category and t.date between :from and :to")
    BigDecimal sumByCategoryBetween(@Param("user") User user, @Param("category") Category category,
                                    @Param("from") LocalDate from, @Param("to") LocalDate to);
}
