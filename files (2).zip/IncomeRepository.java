package com.finova.repository;

import com.finova.entity.Income;

public interface IncomeRepository extends TransactionRepository<Income> { }
