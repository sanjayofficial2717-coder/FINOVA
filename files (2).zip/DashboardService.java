package com.finova.service;

import com.finova.dto.DashboardResponse;
import com.finova.dto.TransactionDtos.TransactionResponse;
import com.finova.entity.Transaction;
import com.finova.entity.User;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.math.BigDecimal;
import java.time.YearMonth;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

@Service
public class DashboardService {

    private final IncomeService incomes;
    private final ExpenseService expenses;
    private final BudgetService budgets;

    public DashboardService(IncomeService incomes, ExpenseService expenses, BudgetService budgets) {
        this.incomes = incomes;
        this.expenses = expenses;
        this.budgets = budgets;
    }

    @Transactional(readOnly = true)
    public DashboardResponse build(User user) {
        YearMonth now = YearMonth.now();
        BigDecimal totalIncome = incomes.totalAll(user);
        BigDecimal totalExpense = expenses.totalAll(user);

        // Polymorphism: Income and Expense are merged and handled uniformly as Transaction.
        List<Transaction> merged = new ArrayList<>(incomes.recent(user));
        merged.addAll(expenses.recent(user));
        List<TransactionResponse> recent = merged.stream()
                .sorted(Comparator.comparing(Transaction::getDate).thenComparing(Transaction::getId).reversed())
                .limit(5)
                .map(TransactionResponse::from)
                .toList();

        return new DashboardResponse(
                totalIncome, totalExpense, totalIncome.subtract(totalExpense),
                incomes.totalBetween(user, now.atDay(1), now.atEndOfMonth()),
                expenses.totalBetween(user, now.atDay(1), now.atEndOfMonth()),
                recent,
                budgets.list(user, now.getYear(), now.getMonthValue()));
    }
}
