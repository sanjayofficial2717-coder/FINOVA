package com.finova.controller;

import com.finova.dto.AuthDtos.AuthResponse;
import com.finova.entity.User;
import com.finova.service.UserService;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/users/me")
public class UserController {

    public record UpdateProfileRequest(@NotBlank @Size(max = 100) String name) { }
    public record ChangePasswordRequest(@NotBlank String oldPassword, @NotBlank @Size(min = 8, max = 72) String newPassword) { }

    private final UserService users;

    public UserController(UserService users) {
        this.users = users;
    }

    @GetMapping
    public AuthResponse me(@AuthenticationPrincipal User user) {
        return new AuthResponse(null, user.getName(), user.getEmail());
    }

    @PutMapping
    public AuthResponse update(@AuthenticationPrincipal User user, @Valid @RequestBody UpdateProfileRequest req) {
        return users.updateName(user, req.name());
    }

    @PutMapping("/password")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void changePassword(@AuthenticationPrincipal User user, @Valid @RequestBody ChangePasswordRequest req) {
        users.changePassword(user, req.oldPassword(), req.newPassword());
    }
}
