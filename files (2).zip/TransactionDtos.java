package com.finova.dto;

import com.finova.entity.Transaction;
import com.finova.entity.TransactionType;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.math.BigDecimal;
import java.time.LocalDate;

public final class TransactionDtos {
    private TransactionDtos() { }

    public record TransactionRequest(
            @NotNull @DecimalMin(value = "0.01", message = "amount must be at least 0.01")
            @Digits(integer = 12, fraction = 2) BigDecimal amount,
            @Size(max = 255) String description,
            @NotNull LocalDate date,
            Long categoryId) { }

    public record TransactionResponse(Long id, TransactionType type, BigDecimal amount, String description,
                                      LocalDate date, Long categoryId, String categoryName) {
        public static TransactionResponse from(Transaction t) {
            var c = t.getCategory();
            return new TransactionResponse(t.getId(), t.getType(), t.getAmount(), t.getDescription(),
                    t.getDate(), c == null ? null : c.getId(), c == null ? null : c.getName());
        }
    }
}
