package com.finova.entity;

import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;
import java.math.BigDecimal;

@Entity
@DiscriminatorValue("INCOME")
public class Income extends Transaction {

    @Override
    public TransactionType getType() { return TransactionType.INCOME; }

    @Override
    public BigDecimal signedAmount() { return getAmount(); }
}
