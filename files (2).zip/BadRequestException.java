package com.finova.exception;

public class BadRequestException extends RuntimeException {
    public BadRequestException(String message) { super(message); }
}
