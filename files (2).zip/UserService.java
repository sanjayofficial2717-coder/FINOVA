package com.finova.service;

import com.finova.dto.AuthDtos.AuthResponse;
import com.finova.entity.User;
import com.finova.exception.BadRequestException;
import com.finova.repository.UserRepository;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/** User management: profile view/update and password change for the authenticated user. */
@Service
public class UserService {

    private final UserRepository users;
    private final PasswordEncoder encoder;

    public UserService(UserRepository users, PasswordEncoder encoder) {
        this.users = users;
        this.encoder = encoder;
    }

    @Transactional
    public AuthResponse updateName(User current, String name) {
        User user = users.findById(current.getId()).orElseThrow();
        user.setName(name.trim());
        return new AuthResponse(null, user.getName(), user.getEmail());
    }

    @Transactional
    public void changePassword(User current, String oldPassword, String newPassword) {
        User user = users.findById(current.getId()).orElseThrow();
        if (!encoder.matches(oldPassword, user.getPasswordHash())) {
            throw new BadRequestException("Current password is incorrect");
        }
        user.setPasswordHash(encoder.encode(newPassword));
    }
}
