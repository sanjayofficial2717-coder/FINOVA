package com.finova.controller;

import com.finova.dto.BudgetDtos.BudgetRequest;
import com.finova.dto.BudgetDtos.BudgetResponse;
import com.finova.entity.User;
import com.finova.service.BudgetService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;
import java.time.YearMonth;
import java.util.List;

@RestController
@RequestMapping("/api/budgets")
public class BudgetController {

    private final BudgetService service;

    public BudgetController(BudgetService service) {
        this.service = service;
    }

    @GetMapping
    public List<BudgetResponse> list(@AuthenticationPrincipal User user,
                                     @RequestParam(required = false) Integer year,
                                     @RequestParam(required = false) Integer month) {
        YearMonth now = YearMonth.now();
        return service.list(user, year == null ? now.getYear() : year, month == null ? now.getMonthValue() : month);
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public BudgetResponse create(@AuthenticationPrincipal User user, @Valid @RequestBody BudgetRequest req) {
        return service.create(user, req);
    }

    @PutMapping("/{id}")
    public BudgetResponse update(@AuthenticationPrincipal User user, @PathVariable Long id,
                                 @Valid @RequestBody BudgetRequest req) {
        return service.update(user, id, req);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@AuthenticationPrincipal User user, @PathVariable Long id) {
        service.delete(user, id);
    }
}
