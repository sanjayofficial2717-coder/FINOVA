package com.finova.entity;

import jakarta.persistence.*;
import java.time.Instant;

/** Abstract parent of all entities: shared id and audit timestamp (inheritance + encapsulation). */
@MappedSuperclass
public abstract class BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, updatable = false)
    private Instant createdAt;

    @PrePersist
    void onCreate() {
        this.createdAt = Instant.now();
    }

    public Long getId() { return id; }
    public Instant getCreatedAt() { return createdAt; }
}
