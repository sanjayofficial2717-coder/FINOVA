package com.finova.dto;

import com.finova.dto.BudgetDtos.BudgetResponse;
import com.finova.dto.TransactionDtos.TransactionResponse;
import java.math.BigDecimal;
import java.util.List;

public record DashboardResponse(BigDecimal totalIncome, BigDecimal totalExpense, BigDecimal balance,
                                BigDecimal monthIncome, BigDecimal monthExpense,
                                List<TransactionResponse> recentTransactions,
                                List<BudgetResponse> budgets) { }
