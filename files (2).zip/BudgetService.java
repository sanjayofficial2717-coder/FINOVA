package com.finova.service;

import com.finova.dto.BudgetDtos.BudgetRequest;
import com.finova.dto.BudgetDtos.BudgetResponse;
import com.finova.entity.Budget;
import com.finova.entity.Category;
import com.finova.entity.TransactionType;
import com.finova.entity.User;
import com.finova.exception.BadRequestException;
import com.finova.exception.DuplicateResourceException;
import com.finova.exception.ResourceNotFoundException;
import com.finova.repository.BudgetRepository;
import com.finova.repository.CategoryRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.YearMonth;
import java.util.List;

@Service
@Transactional
public class BudgetService {

    private final BudgetRepository budgets;
    private final CategoryRepository categories;
    private final ExpenseService expenses;

    public BudgetService(BudgetRepository budgets, CategoryRepository categories, ExpenseService expenses) {
        this.budgets = budgets;
        this.categories = categories;
        this.expenses = expenses;
    }

    @Transactional(readOnly = true)
    public List<BudgetResponse> list(User user, int year, int month) {
        return budgets.findByUserAndPeriodYearAndPeriodMonth(user, year, month).stream()
                .map(b -> toResponse(user, b)).toList();
    }

    public BudgetResponse create(User user, BudgetRequest req) {
        Category c = expenseCategory(user, req.categoryId());
        if (budgets.existsByUserAndCategoryAndPeriodYearAndPeriodMonth(user, c, req.year(), req.month())) {
            throw new DuplicateResourceException("A budget for this category and month already exists");
        }
        Budget b = budgets.save(new Budget(user, c, req.year(), req.month(), req.limitAmount()));
        return toResponse(user, b);
    }

    public BudgetResponse update(User user, Long id, BudgetRequest req) {
        Budget b = find(user, id);
        Category c = expenseCategory(user, req.categoryId());
        boolean moved = !b.getCategory().getId().equals(c.getId())
                || b.getPeriodYear() != req.year() || b.getPeriodMonth() != req.month();
        if (moved && budgets.existsByUserAndCategoryAndPeriodYearAndPeriodMonth(user, c, req.year(), req.month())) {
            throw new DuplicateResourceException("A budget for this category and month already exists");
        }
        b.setCategory(c);
        b.setPeriodYear(req.year());
        b.setPeriodMonth(req.month());
        b.setLimitAmount(req.limitAmount());
        return toResponse(user, b);
    }

    public void delete(User user, Long id) {
        budgets.delete(find(user, id));
    }

    private Budget find(User user, Long id) {
        return budgets.findByIdAndUser(id, user).orElseThrow(() -> new ResourceNotFoundException("Budget not found"));
    }

    private Category expenseCategory(User user, Long id) {
        Category c = categories.findByIdAndUser(id, user)
                .orElseThrow(() -> new ResourceNotFoundException("Category not found"));
        if (c.getType() != TransactionType.EXPENSE) {
            throw new BadRequestException("Budgets can only be set for expense categories");
        }
        return c;
    }

    /** Business logic: spent = sum of the user's expenses in that category during the budget month. */
    private BudgetResponse toResponse(User user, Budget b) {
        YearMonth ym = YearMonth.of(b.getPeriodYear(), b.getPeriodMonth());
        BigDecimal spent = expenses.totalForCategory(user, b.getCategory(), ym.atDay(1), ym.atEndOfMonth());
        BigDecimal remaining = b.getLimitAmount().subtract(spent);
        double pct = spent.multiply(BigDecimal.valueOf(100))
                .divide(b.getLimitAmount(), 1, RoundingMode.HALF_UP).doubleValue();
        return new BudgetResponse(b.getId(), b.getCategory().getId(), b.getCategory().getName(),
                b.getPeriodYear(), b.getPeriodMonth(), b.getLimitAmount(), spent, remaining, pct,
                remaining.signum() < 0);
    }
}
