package com.finova.repository;

import com.finova.entity.Expense;

public interface ExpenseRepository extends TransactionRepository<Expense> { }
