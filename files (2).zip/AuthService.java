package com.finova.service;

import com.finova.dto.AuthDtos.AuthResponse;
import com.finova.dto.AuthDtos.LoginRequest;
import com.finova.dto.AuthDtos.RegisterRequest;
import com.finova.entity.User;
import com.finova.exception.DuplicateResourceException;
import com.finova.repository.UserRepository;
import com.finova.security.JwtService;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class AuthService {

    private final UserRepository users;
    private final PasswordEncoder encoder;
    private final JwtService jwt;

    public AuthService(UserRepository users, PasswordEncoder encoder, JwtService jwt) {
        this.users = users;
        this.encoder = encoder;
        this.jwt = jwt;
    }

    @Transactional
    public AuthResponse register(RegisterRequest req) {
        String email = req.email().trim().toLowerCase();
        if (users.existsByEmail(email)) {
            throw new DuplicateResourceException("An account with this email already exists");
        }
        User user = users.save(new User(req.name().trim(), email, encoder.encode(req.password())));
        return new AuthResponse(jwt.generateToken(user.getEmail()), user.getName(), user.getEmail());
    }

    @Transactional(readOnly = true)
    public AuthResponse login(LoginRequest req) {
        User user = users.findByEmail(req.email().trim().toLowerCase())
                .filter(u -> encoder.matches(req.password(), u.getPasswordHash()))
                .orElseThrow(() -> new BadCredentialsException("Invalid credentials"));
        return new AuthResponse(jwt.generateToken(user.getEmail()), user.getName(), user.getEmail());
    }
}
