package com.finova.controller;

import com.finova.dto.TransactionDtos.TransactionRequest;
import com.finova.dto.TransactionDtos.TransactionResponse;
import com.finova.entity.Transaction;
import com.finova.entity.User;
import com.finova.service.AbstractTransactionService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;
import java.util.List;

/** Shared CRUD endpoints; concrete subclasses only add the base path. */
public abstract class AbstractTransactionController<T extends Transaction> {

    private final AbstractTransactionService<T> service;

    protected AbstractTransactionController(AbstractTransactionService<T> service) {
        this.service = service;
    }

    @GetMapping
    public List<TransactionResponse> list(@AuthenticationPrincipal User user) {
        return service.list(user);
    }

    @GetMapping("/{id}")
    public TransactionResponse get(@AuthenticationPrincipal User user, @PathVariable Long id) {
        return service.get(user, id);
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public TransactionResponse create(@AuthenticationPrincipal User user, @Valid @RequestBody TransactionRequest req) {
        return service.create(user, req);
    }

    @PutMapping("/{id}")
    public TransactionResponse update(@AuthenticationPrincipal User user, @PathVariable Long id,
                                      @Valid @RequestBody TransactionRequest req) {
        return service.update(user, id, req);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@AuthenticationPrincipal User user, @PathVariable Long id) {
        service.delete(user, id);
    }
}
